package com.demo.deepanshu.dao;

import com.demo.deepanshu.model.Transaction;

public interface TransactionDAO {
    void addTransaction(Transaction transaction);

}
