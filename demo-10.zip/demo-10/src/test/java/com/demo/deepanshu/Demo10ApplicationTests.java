package com.demo.deepanshu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
